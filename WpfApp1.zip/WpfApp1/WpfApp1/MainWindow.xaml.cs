﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows.Forms;
using System.ComponentModel;
using System.Threading;
using System.Diagnostics;
using WindowsInput.Native;
using WindowsInput;
using System.Collections.Generic;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        enum Tasks
        {
            ScrollUp,
            ScrollDown,
            Type,
            Backspace,
            MouseMove
        }

        private Tasks ToDo { get; set; }
        DispatcherTimer timer;
        Stopwatch watch;
        int minutes = 0;
        InputSimulator sim = new InputSimulator();

        List<string> texts = new List<string>() {
            "Sapience Ki Ma Ki Aankh",
            "HCL Wale Gadhe Hai",
            "Himanshu Gupta Zindabad",
            "Wo Sikandar hi",
            "Dosto Kehlata h",
            "Hari Baazi ko jeetna",
            "Jisse Aata h",
            "Sapience Murdabad"
        };

        int index = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            switch (ToDo)
            {
                case Tasks.ScrollUp:
                    sim.Mouse.VerticalScroll(20);
                    break;
                case Tasks.ScrollDown:
                    sim.Mouse.VerticalScroll(-20);
                    break;
                case Tasks.Type:
                    index++;
                    if (index == texts.Count)
                        index = 0;
                    sim.Keyboard.TextEntry(texts[index]);
                    break;
                case Tasks.Backspace:
                    for(int i=0;i< texts[index].Length;i++)
                    sim.Keyboard.KeyPress(VirtualKeyCode.BACK);
                    break;
                case Tasks.MouseMove:
                    Random rnd = new Random();
                    sim.Mouse.MoveMouseTo(rnd.Next(500), rnd.Next(500));
                    break;
                default:
                    break;
            }

            ToDo = (Tasks)(((int)ToDo + 1) % 5);
            if (minutes > 0)
            {
                if (watch.Elapsed > TimeSpan.FromMinutes(minutes))
                {
                    System.Windows.Application.Current.Shutdown();
                }
            }
        }

        private void OnTimeSet(object sender, TextChangedEventArgs e)
        {
            int.TryParse((sender as System.Windows.Controls.TextBox).Text, out minutes);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(3000);
            timer.IsEnabled = true;
            timer.Tick += Timer_Tick;

            timer.Start();
            watch = new Stopwatch();
            watch.Start();


            NotifyIcon myIcon = new System.Windows.Forms.NotifyIcon(); 
            Stream iconStream = System.Windows.Application.GetResourceStream(new Uri("pack://application:,,,/WpfApp1;component/HP.ico")).Stream;
            myIcon.Icon = new System.Drawing.Icon(iconStream);
            myIcon.MouseDoubleClick += MyNotifyIcon_MouseDoubleClick;
            myIcon.BalloonTipText = "Sapience Haai Haai !";
            myIcon.Visible = true;

            this.WindowState = WindowState.Minimized;
            this.ShowInTaskbar = false;
        }

        private void MyNotifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void Grid_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
